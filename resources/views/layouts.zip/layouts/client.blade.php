<section id="testimonial" class="service section pt-90">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-heading wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.3s">
                    <h6>Our Clients</h6>
                    <h4>Here is Our Valuable <em>Clients</em></h4>
                    <div class="line-dec"></div>
                </div>
            </div>

            <div class="col-lg-12">

            </div>
        </div>
    </div>
</section>

<div class="brand-area pb-100">
    <div class="container">
        <div class="marquee">
            <div class="marquee-content">
                <img src="assets/images/brand-1.png" alt="">
                <img src="assets/images/brand-2.png" alt="">
                <img src="assets/images/brand-3.png" alt="">
                <img src="assets/images/brand-4.png" alt="">
                <img src="assets/images/brand-5.png" alt="">

                <!-- Duplicate row for smooth infinite loop -->
                <img src="assets/images/brand-1.png" alt="">
                <img src="assets/images/brand-2.png" alt="">
                <img src="assets/images/brand-3.png" alt="">
                <img src="assets/images/brand-4.png" alt="">
                <img src="assets/images/brand-5.png" alt="">
            </div>
        </div>
    </div>
</div>
